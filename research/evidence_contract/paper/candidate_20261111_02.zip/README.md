# Development replication candidate

This local candidate verifies saved development observations and replays five original
test oracles against fictional specimen graphs and existing reader outputs.

Run "python -I -B verify_results.py" for the standard-library aggregate and hash check.
Run "python -I -B verify_results.py --oracle" in the existing research environment to
replay A, B0, B2, B3 and A_flat. The second command requires NumPy, Pillow and OpenCV.
Exact package versions are recorded in ENVIRONMENT.json. Both modes make zero model calls.

The data contain 132 scheduled development comparisons, constructed fault results,
and stage-pilot observations. Graph values and reader outputs refer to authored,
fictional specimens. Source code is copied byte-for-byte for the scored methods.
All input references and eligibility decisions come from the frozen development study.
The archive does not independently establish human legibility or completeness of
the original validation inventory. It contains no human IFV submissions.

An exact result replay demonstrates computational reproducibility of the stored
decisions. Independent replication, confirmatory evidence, model-inference
reproduction, dataset rights review and final anonymous release review remain pending.
Model weights, customer information, training data, machine paths and author metadata
are outside this candidate. The copied source is supplied for inspection and the
documented score-only entry point. License and third-party redistribution review must
be completed before an external release. No archive has been published.
