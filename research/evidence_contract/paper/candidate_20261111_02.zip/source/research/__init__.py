"""Anonymous development score replay package."""
