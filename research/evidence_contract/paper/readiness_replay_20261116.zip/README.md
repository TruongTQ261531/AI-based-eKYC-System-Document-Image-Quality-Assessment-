# Public development replay (16 November 2026)

This is not a final anonymous conference supplement. Inputs and requirements
are authored after two historical parser faults were known. No image, human
review submission, model output cache, weights or compiler is included.

With standard Python 3.10+, from this extracted directory:

    python -I -B verify_parser.py parser

The verifier checks five pinned parser versions, 118 authored cases and two
minimal witnesses (596 calls). It validates computational reproduction against
the saved author requirements, not independent reference truth. It does not
independently replay timings or budget permutations. They are descriptive
development measurements; two fault families are not 76 independent defects.

The representation files contain 255 abstract source configurations and 164
injected boundary controls. They are not natural-model outputs. Their full
re-execution uses the repository renderer and frozen oracle dependencies;
provenance code is included for inspection, not a standalone image replay.

The PDF is a three-page internal Emerging Results draft. Author/novelty review,
final anonymity, redistribution and conference-format checks remain open.
MANIFEST.json binds every included file. Hashes establish integrity, not truth.
