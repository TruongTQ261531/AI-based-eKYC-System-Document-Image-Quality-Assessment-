# IFV aggregate supplement (local candidate)

Run `python -I -B verify_ifv_aggregate.py` after extraction. Only the Python
standard library is required. The script verifies file integrity, endpoint
counts, rate denominators, preserved sensitivity frame and all-alarm accounting.
It makes no model calls and contains no predictor or training loader.

This is one project-author's unadjudicated development review: 46 submitted
comparisons, 42 primary and four diagnostic. Both original and post-hoc
withholding results are retained. No observation, transcript, human note,
image, reader prediction or reviewer identifier is included.

Aggregate verification is not score-level replay, independent adjudication,
reproduction of human observations, or a confirmatory result. The original
score-replay candidate remains a separate artifact. Final rights, anonymity
and release review remain pending; this candidate has not been published.
