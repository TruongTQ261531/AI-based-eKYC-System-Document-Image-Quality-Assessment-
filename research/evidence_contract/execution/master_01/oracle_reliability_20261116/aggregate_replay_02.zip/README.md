# B public arithmetic replay, 16 November 2026

Extract this archive, then run with Python 3.11 or newer:

    python -I -B verify.py run_02

Expected: PASS; 58 controls, 492 metric groups, 823 public contingency cells.
The stdlib verifier checks hashes, expected states, equal-information parity,
control-to-cell consistency, independent arithmetic and paired denominators.
It does NOT reexecute the policy, reproduce private human labels, verify their
truth or establish external reference approval. No model/weights are required.

Control cases are authored symbolic inputs/outputs: 0 images, 0 physical IDs.
Historical rows are aggregate only and retain original/withholding panels.
Three primary physical IDs and one author's phase-2 review do not support
population inference. An origin-flag negative test is still an injected control.

NO_GO_SUPERIORITY; no new training, inference, human review or confirmatory run.
This development package is not a final anonymous conference supplement.
PACKAGE_MANIFEST.json binds included files; the external receipt binds the ZIP.
